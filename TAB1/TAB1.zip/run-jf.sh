#!/bin/bash
sudo mn -c

#sudo python lib/pox.py DCController --topo=ft,4 --routing=ECMP

for f in 1 8; do
    for i in 1 2 3; do
	python jellyfish.py -t jf -r ksp -dir tp_results_jf_ksp_$i -e t -f $f
	python jellyfish.py -t jf -r ecmp -dir tp_results_jf_ecmp_$i -e t -f $f
	#python jellyfish.py -t ft -r random -np 4 -dir tp_results_ft_ecmp_$i -e t -f $f
    #python jellyfish.py -t ft -r random -np 4 -dir tp_results_ft_mptcp_$i -e t -f $f --cong mptcp
    done

    python compile_throughput.py -dir tp_results -o result-throughput_jf$f.txt -f $f
    cp -r tp_results* ./results/
    rm -r tp_results* # so second run does not double count files
done
